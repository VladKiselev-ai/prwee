# ⚡ Быстрая настройка API ключей

## 🚨 Текущая проблема

Все API ключи не настроены (placeholder значения), поэтому:
- ❌ Telegram уведомления не работают (ошибка 404)
- ❌ AI-аналитика не работает
- ❌ Email уведомления не работают

## ✅ Ваш ChatId: `594250971`

## 🔧 Быстрое решение (5 минут)

### 1. Telegram Bot (самый важный)

**Создайте бота за 2 минуты:**
1. Откройте Telegram
2. Найдите @BotFather
3. Отправьте `/newbot`
4. Название: `News Bot`
5. Username: `your_news_bot`
6. **Скопируйте токен** (начинается с цифр)

**Обновите .env.local:**
```bash
nano .env.local

# Замените:
TELEGRAM_BOT_TOKEN=your_telegram_bot_token

# На ваш токен:
TELEGRAM_BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrsTUVwxyz
```

### 2. OpenAI API (опционально)

**Получите ключ за 1 минуту:**
1. https://platform.openai.com/api-keys
2. Create new secret key
3. **Скопируйте ключ** (начинается с `sk-`)

**Обновите .env.local:**
```env
OPENAI_API_KEY=sk-your-actual-key-here
```

### 3. Email (опционально)

**Настройте Gmail за 2 минуты:**
1. Включите 2FA в Google
2. https://myaccount.google.com/apppasswords
3. Создайте App Password для Mail
4. **Скопируйте пароль** (16 символов)

**Обновите .env.local:**
```env
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-16-char-password
SMTP_FROM=your-email@gmail.com
```

## 🚀 Перезапуск и тестирование

```bash
# 1. Перезапустите сервер
# Остановите (Ctrl+C)
npm run dev

# 2. Протестируйте Telegram
curl -X POST http://localhost:3000/api/test/telegram \
  -H "Content-Type: application/json" \
  -d '{"chatId": "594250971", "message": "Тест! 🎉"}'

# 3. Откройте веб-интерфейс
# http://localhost:3000/test-api
```

## 🎯 Ожидаемый результат

После настройки Telegram:
```json
{
  "success": true,
  "data": {
    "chatId": "594250971",
    "message": "Тест! 🎉",
    "sentAt": "2025-06-20T..."
  },
  "message": "Telegram сообщение отправлено успешно!"
}
```

## 📱 Что вы получите

### С Telegram:
- 🚨 Уведомления о важных новостях
- 📰 Ежедневные дайджесты
- 📊 Статистика по категориям

### С OpenAI:
- 🤖 AI-анализ статей
- 📝 Автоматические выжимки
- 😊 Анализ настроения

### С Email:
- 📧 Email дайджесты
- 🔔 Уведомления по email

## 🔗 Полезные ссылки

- **Тест API**: http://localhost:3000/test-api
- **Тест уведомлений**: http://localhost:3000/test-notifications
- **Подробная инструкция**: API_KEYS_SETUP.md

---

**💡 Совет: Начните с Telegram - это самый быстрый способ получить уведомления!** 