# 🔑 Настройка API ключей

## 📋 Текущий статус .env.local

Все ключи установлены как placeholder значения:

```env
# OpenAI API
OPENAI_API_KEY=your_openai_api_key_here

# Email (Gmail)
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_app_password

# Telegram Bot
TELEGRAM_BOT_TOKEN=your_telegram_bot_token
```

## 🚨 Проблема

**Ошибка 404 Not Found** при тестировании Telegram означает, что токен бота не настроен.

## 🔧 Пошаговая настройка

### 1. Telegram Bot Token

#### Создание бота:
1. Откройте Telegram
2. Найдите @BotFather
3. Отправьте `/newbot`
4. Введите название: `News Bot`
5. Введите username: `your_news_bot` (должен заканчиваться на 'bot')
6. **Скопируйте токен** (выглядит как `123456789:ABCdefGHIjklMNOpqrsTUVwxyz`)

#### Настройка в .env.local:
```bash
# Откройте файл
nano .env.local

# Найдите строку:
TELEGRAM_BOT_TOKEN=your_telegram_bot_token

# Замените на ваш токен:
TELEGRAM_BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrsTUVwxyz
```

### 2. OpenAI API Key

#### Получение ключа:
1. Перейдите на https://platform.openai.com/api-keys
2. Войдите в аккаунт
3. Нажмите "Create new secret key"
4. **Скопируйте ключ** (начинается с `sk-`)

#### Настройка в .env.local:
```env
OPENAI_API_KEY=sk-your-actual-openai-key-here
```

### 3. Email (Gmail SMTP)

#### Настройка Gmail:
1. Включите двухфакторную аутентификацию
2. Перейдите на https://myaccount.google.com/apppasswords
3. Создайте App Password для "Mail"
4. **Скопируйте пароль** (16 символов)

#### Настройка в .env.local:
```env
SMTP_USER=your-actual-email@gmail.com
SMTP_PASS=your-16-character-app-password
SMTP_FROM=your-actual-email@gmail.com
```

## 🧪 Тестирование

### После настройки всех ключей:

1. **Перезапустите сервер**:
```bash
# Остановите (Ctrl+C)
npm run dev
```

2. **Протестируйте API**:
```bash
# Telegram
curl -X POST http://localhost:3000/api/test/telegram \
  -H "Content-Type: application/json" \
  -d '{"chatId": "594250971", "message": "Тест!"}'

# OpenAI
curl -X POST http://localhost:3000/api/test/openai \
  -H "Content-Type: application/json" \
  -d '{"text": "Тест OpenAI API"}'

# Email
curl -X POST http://localhost:3000/api/test/email \
  -H "Content-Type: application/json" \
  -d '{"to": "test@example.com", "subject": "Тест", "content": "Тест email"}'
```

3. **Через веб-интерфейс**:
- http://localhost:3000/test-api
- http://localhost:3000/test-notifications

## 🎯 Ожидаемые результаты

### Успешный Telegram тест:
```json
{
  "success": true,
  "data": {
    "chatId": "594250971",
    "message": "Тест!",
    "sentAt": "2025-06-20T..."
  },
  "message": "Telegram сообщение отправлено успешно!"
}
```

### Успешный OpenAI тест:
```json
{
  "success": true,
  "data": {
    "summary": "Краткое описание...",
    "keyPoints": ["Пункт 1", "Пункт 2"],
    "trends": ["Тренд 1"],
    "recommendations": ["Рекомендация 1"]
  }
}
```

## 🔍 Диагностика проблем

### Telegram ошибки:
- **404 Not Found**: Токен неверный или бот не добавлен в чат
- **403 Forbidden**: Бот заблокирован пользователем
- **400 Bad Request**: Неверный формат chatId

### OpenAI ошибки:
- **401 Unauthorized**: Неверный API ключ
- **429 Too Many Requests**: Превышен лимит запросов
- **500 Internal Server Error**: Проблемы с сервером OpenAI

### Email ошибки:
- **535 Authentication failed**: Неверные SMTP данные
- **550 User not found**: Неверный email получателя
- **553 Mail from must equal authorized user**: SMTP_FROM не совпадает с SMTP_USER

## 📋 Чек-лист

- [ ] Telegram бот создан через @BotFather
- [ ] Telegram токен добавлен в .env.local
- [ ] OpenAI API ключ получен и добавлен
- [ ] Gmail App Password создан
- [ ] SMTP настройки добавлены в .env.local
- [ ] Сервер перезапущен после изменений
- [ ] Все API протестированы

## 🔗 Полезные ссылки

- **Telegram BotFather**: @BotFather
- **OpenAI API Keys**: https://platform.openai.com/api-keys
- **Gmail App Passwords**: https://myaccount.google.com/apppasswords
- **Тест API**: http://localhost:3000/test-api

---

**🎉 После настройки всех ключей система будет полностью функциональной!** 