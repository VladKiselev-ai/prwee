# 🔑 Обновление OpenAI API ключа

## ✅ Ваш API ключ получен!

**Ваш OpenAI API ключ:**
```
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
```

## 🔧 Шаг 1: Создайте файл .env.local

```bash
# В терминале в папке проекта
touch .env.local
```

## 🔧 Шаг 2: Добавьте ваш ключ

Откройте файл `.env.local` и добавьте:

```env
# OpenAI API Key для AI-анализа
OPENAI_API_KEY=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

# Telegram Bot (опционально)
TELEGRAM_BOT_TOKEN=your_telegram_bot_token_here
TELEGRAM_CHAT_ID=594250971

# Email SMTP (опционально)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-app-password
EMAIL_FROM=your-email@gmail.com

# NextAuth (опционально)
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=your-nextauth-secret-here
```

## 🔧 Шаг 3: Перезапустите сервер

```bash
# Остановите сервер (Ctrl+C)
# Затем запустите заново:
npm run dev
```

## 🧪 Шаг 4: Тестирование

### Тест API:
```bash
curl -X POST http://localhost:3000/api/articles/analyze \
  -H "Content-Type: application/json" \
  -d '{"includeContext": true}'
```

### Тест через веб-интерфейс:
1. Откройте http://localhost:3000/ai-analysis
2. Выберите статью
3. Нажмите "Анализировать"

## 🎯 Ожидаемый результат

После настройки вы должны увидеть:
- ✅ Успешный анализ статьи
- ✅ Структурированные данные (важность, настроение, факты)
- ✅ Исторический контекст и предысторию
- ✅ Прогнозы развития событий

## 💰 Стоимость

- **GPT-4o-mini**: ~$0.00015 за 1K токенов
- **Один анализ**: ~$0.15-0.30
- **100 анализов**: ~$15-30

---

**🎉 После выполнения этих шагов AI-анализ будет полностью работать!** 