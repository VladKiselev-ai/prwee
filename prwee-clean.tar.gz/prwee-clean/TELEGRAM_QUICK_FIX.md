# 🚨 Быстрое исправление Telegram

## ❌ Проблема: Ошибка 404 Not Found

Это означает, что **токен бота не настроен** или **бот не добавлен в чат**.

## ✅ Ваш ChatId: `594250971`

## 🔧 Быстрое решение:

### 1. Создайте бота (если еще не создали)
```bash
# Откройте Telegram
# Найдите @BotFather
# Отправьте: /newbot
# Название: News Bot
# Username: your_news_bot
# Скопируйте токен
```

### 2. Обновите .env.local
```bash
# Откройте файл
nano .env.local

# Найдите строку:
TELEGRAM_BOT_TOKEN=your_telegram_bot_token

# Замените на ваш токен:
TELEGRAM_BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrsTUVwxyz
```

### 3. Перезапустите сервер
```bash
# Остановите (Ctrl+C)
# Запустите заново:
npm run dev
```

### 4. Добавьте бота в чат
1. Найдите вашего бота по username
2. Нажмите "Start" или отправьте `/start`
3. Или добавьте в группу

### 5. Протестируйте
```bash
curl -X POST http://localhost:3000/api/test/telegram \
  -H "Content-Type: application/json" \
  -d '{
    "chatId": "594250971", 
    "message": "Тест после настройки! 🎉"
  }'
```

## 🎯 Ожидаемый результат:
```json
{
  "success": true,
  "data": {
    "chatId": "594250971",
    "message": "Тест после настройки! 🎉",
    "sentAt": "2025-06-20T..."
  },
  "message": "Telegram сообщение отправлено успешно!"
}
```

## 🔗 Полезные ссылки:
- Тест через веб: http://localhost:3000/test-api
- Тест уведомлений: http://localhost:3000/test-notifications
- Подробная инструкция: TELEGRAM_SETUP.md

---

**💡 Если все еще не работает, проверьте:**
1. Правильность токена (должен начинаться с цифр)
2. Бот добавлен в чат
3. Сервер перезапущен после изменения .env.local 