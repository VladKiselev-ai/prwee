# Инструкции по установке новостного агрегатора

## Предварительные требования

### 1. Установка Node.js

#### macOS (через Homebrew):
```bash
# Установка Homebrew (если не установлен)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Установка Node.js
brew install node
```

#### macOS (прямая установка):
```bash
# Скачайте установщик с https://nodejs.org/
# Или используйте nvm:
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
nvm install 18
nvm use 18
```

#### Windows:
```bash
# Скачайте установщик с https://nodejs.org/
# Или используйте Chocolatey:
choco install nodejs
```

#### Linux (Ubuntu/Debian):
```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
```

### 2. Установка MongoDB

#### macOS (через Homebrew):
```bash
brew tap mongodb/brew
brew install mongodb-community
brew services start mongodb/brew/mongodb-community
```

#### Windows:
```bash
# Скачайте установщик с https://www.mongodb.com/try/download/community
# Или используйте Chocolatey:
choco install mongodb
```

#### Linux (Ubuntu):
```bash
wget -qO - https://www.mongodb.org/static/pgp/server-6.0.asc | sudo apt-key add -
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/6.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-6.0.list
sudo apt-get update
sudo apt-get install -y mongodb-org
sudo systemctl start mongod
sudo systemctl enable mongod
```

#### Альтернатива: MongoDB Atlas (облачная база данных)
1. Зарегистрируйтесь на https://www.mongodb.com/atlas
2. Создайте бесплатный кластер
3. Получите строку подключения

## Установка проекта

### 1. Переход в папку проекта и установка зависимостей
```bash
# Перейдите в папку проекта (уже находитесь в prwee)
cd /Users/vladislavkiselev/Desktop/prwee

# Установите зависимости
npm install
```

### 2. Настройка переменных окружения
```bash
# Скопируйте пример файла
cp env.example .env.local

# Отредактируйте файл .env.local
nano .env.local
```

#### Обязательные настройки в .env.local:

```env
# База данных
MONGODB_URI=mongodb://localhost:27017/news-aggregator
# Или для MongoDB Atlas:
# MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/news-aggregator

# OpenAI API (опционально, для AI-выжимок)
OPENAI_API_KEY=your_openai_api_key_here

# Email настройки (опционально)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_app_password
SMTP_FROM=your_email@gmail.com

# Telegram Bot (опционально)
TELEGRAM_BOT_TOKEN=your_telegram_bot_token
```

### 3. Инициализация базы данных
```bash
# Запустите скрипт инициализации
npm run init-db
```

Этот скрипт создаст:
- 8 основных категорий новостей
- 3 подкатегории
- RSS источники для каждой категории

### 4. Запуск приложения
```bash
# Режим разработки
npm run dev

# Приложение будет доступно по адресу: http://localhost:3000
```

## Настройка дополнительных сервисов

### OpenAI API (для AI-выжимок)
1. Зарегистрируйтесь на https://platform.openai.com/
2. Получите API ключ
3. Добавьте ключ в .env.local

### Email уведомления (Gmail)
1. Включите двухфакторную аутентификацию
2. Создайте App Password: https://myaccount.google.com/apppasswords
3. Добавьте настройки в .env.local

### Telegram Bot
1. Создайте бота через @BotFather в Telegram
2. Получите токен
3. Добавьте токен в .env.local

## Проверка установки

### 1. Проверка API
```bash
# Проверка категорий
curl http://localhost:3000/api/categories

# Проверка статей
curl http://localhost:3000/api/articles

# Проверка дайджеста
curl http://localhost:3000/api/digest/technology
```

### 2. Проверка веб-интерфейса
1. Откройте http://localhost:3000
2. Убедитесь, что категории отображаются
3. Проверьте навигацию

## Возможные проблемы и решения

### Ошибка "Cannot find module"
```bash
# Переустановите зависимости
rm -rf node_modules package-lock.json
npm install
```

### Ошибка подключения к MongoDB
```bash
# Проверьте, что MongoDB запущен
brew services list | grep mongodb
# Или
sudo systemctl status mongod
```

### Ошибка порта 3000 занят
```bash
# Найдите процесс
lsof -i :3000
# Завершите процесс
kill -9 <PID>
```

### Ошибки TypeScript
```bash
# Очистите кэш TypeScript
rm -rf .next
npm run dev
```

## Структура проекта после установки

```
prwee/
├── .env.local              # Переменные окружения
├── .next/                  # Кэш Next.js
├── node_modules/           # Зависимости
├── app/                    # Приложение
├── components/             # React компоненты
├── lib/                    # Утилиты
├── models/                 # Модели MongoDB
├── scripts/                # Скрипты
├── types/                  # TypeScript типы
├── package.json            # Зависимости
├── tsconfig.json           # Конфигурация TypeScript
└── README.md               # Документация
```

## Следующие шаги

1. **Добавьте RSS источники** - отредактируйте категории в базе данных
2. **Настройте уведомления** - добавьте email/Telegram настройки
3. **Настройте AI-аналитику** - добавьте OpenAI API ключ
4. **Добавьте аутентификацию** - реализуйте систему пользователей
5. **Настройте автоматические задачи** - cron для обновления RSS

## Поддержка

Если у вас возникли проблемы:
1. Проверьте логи в консоли
2. Убедитесь, что все зависимости установлены
3. Проверьте настройки в .env.local
4. Создайте Issue в репозитории

---

**Удачной работы с новостным агрегатором! 🚀** 